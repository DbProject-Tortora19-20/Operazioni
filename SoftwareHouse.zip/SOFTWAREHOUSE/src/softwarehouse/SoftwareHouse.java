package softwarehouse;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedList;
import java.util.List;
import java.util.TimeZone;
import java.sql.Date;
import java.sql.DriverManager;
public class SoftwareHouse 
{
	private static String username;
	private static String password;
	public final Inserire add=new Inserire();
	public final Aggiornare update=new Aggiornare();
	public final Visualizzare show=new Visualizzare();
	private static List<Connection> freeDbConnections;
	
	public SoftwareHouse() {
		try 
		{
		freeDbConnections=new LinkedList<Connection>();	
		Class.forName("com.mysql.cj.jdbc.Driver");
		}
		catch(ClassNotFoundException e) 
		{
			e.printStackTrace();
		} 
	}
	private static Connection createDBConnection() {
		try
		{
			String url="jdbc:mysql://localhost:3306/SoftwareHouse";
			Connection conn=DriverManager.getConnection(url+"?serverTimezone="+TimeZone.getDefault().getID(),username,password);
			conn.setAutoCommit(false);
			return conn;
		}
		catch(SQLException e) 
		{
			e.printStackTrace();
			return null;
		}
	}
	public static synchronized Connection getConnection() {
		Connection connection;

		if (!freeDbConnections.isEmpty()) {
			connection = (Connection) freeDbConnections.get(0);
			SoftwareHouse.freeDbConnections.remove(0);
			try {
				if (connection.isClosed())
					connection = SoftwareHouse.getConnection();
			} catch (SQLException e) {
				try {
					if (connection != null) {
						connection.close();
						connection=null;
					}
				}catch(SQLException e1) {
					System.out.println(e1.getMessage());
				}
				connection = SoftwareHouse.getConnection();
			}
		} else {
			connection = SoftwareHouse.createDBConnection();
		}

		return connection;
	}

	public static synchronized void releaseConnection(Connection connection) {
		try {
			connection.commit();
			SoftwareHouse.freeDbConnections.add(connection);
		} catch (SQLException e) {
			System.err.println(e.getMessage());
		}
	}
	
	public boolean TestConnection() 
	{
		Connection con;
		con=SoftwareHouse.getConnection();
		if(con==null)
			return false;
		return true;
	}
	
	

	public void setUsername(String username) {
		SoftwareHouse.username = username;
	}

	public void setPassword(String password) {
		SoftwareHouse.password = password;
	}
	
	//prende in input la connesione da rilasciare
	//se la connesione � diverso da null chiudo l'oggetto e lo porto a null
	public final class Visualizzare
	{
		private PreparedStatement pst;
		private Connection conn;
		private ResultSet rs;
		private Visualizzare() 
		{
			pst=null;
			conn = null;
			rs=null;
		}
		private void execQuery(String query) 
		{
			try 
			{
				pst=conn.prepareStatement(query);
				rs=pst.executeQuery();
			}
			catch (SQLException e) 
			{
				e.printStackTrace();
			}
		}
		public void numEsamiPrivato(int Codice)
		{
			try 
			{
				conn=getConnection();
				if(conn==null) 
					return;
				String sql= "select corso_formativo.CodiceCF,corso_formativo.Descrizione,corso_formativo.Numero_esami,segue.numero_esami_dati " + 
							"from privato inner join segue on privato.Cliente_CodiceC=segue.Cliente_CodiceC " + 
							"inner join corso_formativo on segue.Corso_Formativo_CodiceCF=corso_formativo.CodiceCF " + 
							"where privato.Cliente_CodiceC= "+Codice+" ;";
				execQuery(sql);
				if(rs.next())
				{
					String codiceCF=rs.getString("CodiceCF");
					String Descr=rs.getString("Descrizione");
					int esami=rs.getInt("Numero_Esami");
					int esami_dati=rs.getInt("numero_esami_dati");
					System.out.printf("%s %s %d %d\n",codiceCF,Descr,esami,esami_dati);
				}
				rs.close();
				pst.close();
			}
			catch(SQLException e) 
			{
				e.printStackTrace();
			}
			finally
			{
				releaseConnection(conn);
			}
		}
		/*Visualizzare il numero di esami mancanti per ogni Cliente inerenti ad un Corso Formativo.*/
		public  void esamiMancanti(int Codice) 
		{
			try
			{
				conn=getConnection();
				String query="select segue.Cliente_CodiceC, Numero_esami-Numero_esami_dati as Esami_mancanti " + 
							 "from segue inner join corso_formativo on corso_formativo.CodiceCF=segue.Corso_Formativo_CodiceCF " + 
							 "where corso_formativo.CodiceCF="+Codice+" ;";
				execQuery(query);
				if(rs.next())
				{
					int codiceC=rs.getInt("Cliente_CodiceC");
					int esami_mancanti=rs.getInt("Esami_mancanti");
					System.out.printf("%d %d \n",codiceC,esami_mancanti);
				}
				rs.close();
				pst.close();
			}
			catch(SQLException e) 
			{
				e.printStackTrace();
			}
			finally
			{
				releaseConnection(conn);
			}
		}
		/*Mostrare quali Azienda hanno conseguito almeno n esami.*/
		public void esami(int numEsami) 
		{
			try 
			{
				conn=getConnection();
				String query="select azienda.* " + 
							 "from azienda inner join cliente on privato.Cliente_CodiceC=cliente.CodiceC " + 
						 	 "inner join segue on segue.Cliente_codiceC=cliente.CodiceC " + 
							 "where numero_esami_dati> "+numEsami+" ;";
				execQuery(query);
				while(rs.next()) 
				{
					String partita_iva=rs.getString("Partita_iva");
					String ragione_Sociale=rs.getString("Ragione_sociale");
					int CodiceC=rs.getInt("Cliente_CodiceC");
					System.out.printf("%s %s %d\n",partita_iva,ragione_Sociale,CodiceC);
				}
				rs.close();
				pst.close();
			}
			catch(SQLException e) 
			{
				e.printStackTrace();
			}
			finally
			{
				releaseConnection(conn);
			}
		}
		/*Visualizzare gli Operatori che hanno preso in carico un determinato Problema. */
		public void OperatoriInCarico(int  Numero,int CodiceS) 
		{
			try
			{
				conn=getConnection();
				String query="select operatore.* " + 
						"from operatore inner join problema on operatore.CodiceO=problema.Operatore_CodiceO " + 
						"where problema.Software_CodiceS= "+CodiceS+" AND problema.Numero= "+Numero+" ; ";
				execQuery(query);
				while(rs.next())
				{
					String CF=rs.getString("CF");
					String Cognome=rs.getString("Cognome");
					String nome=rs.getString("Nome");
					Date date=rs.getDate("Data_nascita");
					String ruolo=rs.getNString("Ruolo");
					int CodiceO=rs.getInt("CodiceP");
					System.out.printf("%d %s %s %s %s %s\n",CodiceO,Cognome,nome,date,CF,ruolo);
				}
				rs.close();
				pst.close();
			}
			catch(SQLException e) 
			{
				e.printStackTrace();
			}
			finally
			{
				releaseConnection(conn);
			}
		}
		/*Stampare tutti i Sistemi Operativi compatibili per uno specifico Software.*/
		public void sitemiCompatibiliS(int Codice) 
		{
			try
			{
				conn=getConnection();
				String query="select sistema_operativo.Sistema " + 
							 "from software inner join sistema_operativo on software.CodiceS=sistema_operativo.Software_CodiceS " + 
							 "where sistema_operativo.Software_CodiceS= "+Codice+" ;";
				execQuery(query);
				while(rs.next()) 
				{
					String codiceS=rs.getString("Sistema");
					System.out.printf("%s\n",codiceS);
				}
				rs.close();
				pst.close();
			}
			catch(SQLException e)
			{
				e.printStackTrace();
			}
			finally
			{
				releaseConnection(conn);
			}
		}
		/*Mostrare tutti i Clienti che hanno speso un totale di p Euro.*/
		public void acquistoSoftware(float Prezzo) 
		{
			try 
			{
				conn=getConnection();
				String query="select cliente.* " + 
						"from cliente inner join acquista on cliente.CodiceC=acquista.Cliente_CodiceC " + 
						"inner join software on software.CodiceS=acquista.Software_CodiceS " + 
						"group by cliente.CodiceC " + 
						"having sum(prezzo)> ? ; ";
				execQuery(query);
				while(rs.next()) 
				{
					String Indirizzo=rs.getString("Indirizzo");
					int CodiceC=rs.getInt("CodiceC");
					float prezzo=rs.getFloat("prezzo");
					System.out.printf("%d %s %f\n",CodiceC,Indirizzo,prezzo);
				}
				rs.close();
				pst.close();
			}
			catch(SQLException e) 
			{
				e.printStackTrace();
			}
			finally
			{
				releaseConnection(conn);
			}
		}
		/*Visualizzare l'elenco di tutti gli Attestati conseguiti da un Cliente.*/
		public void elencoAttestati(int Codice) 
		{
			try
			{
				conn=getConnection();
				String query="select attestato.Corso_Formativo_CodiceCF,corso_formativo.Descrizione,attestato.data_rilascio " + 
							 "from attestato inner join corso_formativo on attestato.Corso_Formativo_CodiceCF=corso_formativo.CodiceCF " + 
							 "where attestato.Cliente_CodiceC= "+Codice+" ;";
				execQuery(query);
				while(rs.next())
				{
					int CodiceCF=rs.getInt("Corso_Formativo_CodiceCF");
					String Descrizione=rs.getString("Descrizione");
					Date data=rs.getDate("data_rilascio");
					System.out.printf("%d %s %s\n",CodiceCF,Descrizione,data);
				}
				rs.close();
				pst.close();
			}
			catch(SQLException e)
			{
				e.printStackTrace();
			}
			finally
			{
				releaseConnection(conn);
			}
		}
		/*Stampare tutte le Aziende alle quali potrebbe interessare uno specifico Software in base agli acquisti, inserito un tipo di riferimento.*/
		public void aziendeInteressate(String tipo) 
		{
			try 
			{
				conn=getConnection();
				String query="select azienda.* " + 
							 "from software inner join acquista on software.CodiceS=acquista.Software_CodiceS " + 
							 "inner join cliente on cliente.CodiceC=acquista.Cliente_CodiceC " + 
							 "inner join azienda on azienda.Cliente_CodiceC=cliente.CodiceC " + 
							 "where software.tipo= '"+tipo+"' ; ";
				execQuery(query);
				while(rs.next()) 
				{
					int CodiceC=rs.getInt("Cliente_CodiceC");
					String Partita_iva=rs.getString("partita_iva");
					String ragioneSociale=rs.getString("ragione_sociale");
					System.out.printf(" %s %s %d\n",Partita_iva,ragioneSociale,CodiceC);
				}
				rs.close();
				pst.close();
			}
			catch(SQLException e) 
			{
				e.printStackTrace();
			}
			finally
			{
				releaseConnection(conn);
			}
		}
		/*Visualizzare i clienti che hanno conseguito un numero di esami pari a quelli previsti dal corso formativo*/
		public void ClientiEsami() 
		{
			try 
			{
				conn=getConnection();
				String query="select cliente.CodiceC,cliente.Indirizzo, corso_formativo.CodiceCF,corso_formativo.Descrizione " + 
							 "from cliente inner join segue on cliente.codiceC=segue.Cliente_CodiceC " + 
							 "join corso_formativo  on segue.Corso_Formativo_CodiceCF=corso_formativo.CodiceCF " + 
							 "where segue.Numero_esami_dati=corso_formativo.Numero_esami ; ";
				execQuery(query);
				if(rs==null) 
				{
					System.out.println("Non sono presenti valori");
					return;
				}
				while(rs.next())
				{
					int CodiceC=rs.getInt("CodiceC");
					String indirizzo=rs.getString("Indirizzo");
					int CodiceCF=rs.getInt("CodiceCF");
					String Descrizione=rs.getString("Descrizione");
					System.out.printf("%d %s %d %s",CodiceC,indirizzo,CodiceCF,Descrizione);
				}
				pst.close();
				rs.close();
			}
			catch(SQLException e) 
			{
				e.printStackTrace();
			}
			finally
			{
				releaseConnection(conn);
			}
		}
	}
	public final class Inserire 
	{
		private PreparedStatement pst;
		private ResultSet rs;
		private Connection conn;
		private int key;
		private Inserire() 
		{
			pst=null;
			conn = null;
			rs=null;
		}
		private int execUpdate(String query)
		{
			try 
			{
				int n;
				pst=conn.prepareStatement(query);
				n=pst.executeUpdate();
				pst.close();
				return n;
			} 
			catch (SQLException e) 
			{
				e.printStackTrace();
				return 0;
			}
		}
		private void execQuery(String query) 
		{
			try
			{
				pst=conn.prepareStatement(query);
				rs=pst.executeQuery();
			} 
			catch (SQLException e) 
			{
				e.printStackTrace();
			}
		}
		/*Inserire un Cliente.*/
		private int addCliente(String Indirizzo)
		{
			int n;
			try {
				conn=SoftwareHouse.getConnection();
				String query="select max(CodiceC) as MaxCodiceC from cliente; ";
				execQuery(query);
				if(rs.next()) {
					key=rs.getInt("MaxCodiceC");
					key++;
					rs.close();
					pst.close();
					query="insert into cliente(CodiceC,Indirizzo) values( "+key+" , '"+Indirizzo+"' );";
					n=execUpdate(query);
					releaseConnection(conn);
					return n;
				}
			} catch (SQLException e) {
				releaseConnection(conn);
				System.out.println(e.getMessage());
			}
			return 0;
		}

		public int addClienteAziende(String Indirizzo,String partita_iva,String ragioneSociale) {
			int n;
			n=addCliente(Indirizzo);
			if(n!=0){
				conn=SoftwareHouse.getConnection();
				String query="insert into azienda(cliente_CodiceC,Partita_iva,Ragione_sociale) values( "+key+" , '"+partita_iva+"' , '"+ragioneSociale+"') ; ";
				n=execUpdate(query);
				releaseConnection(conn);
				return n;
			}
			return 0;
		}
		
		public int addClientePrivato(String Indirizzo,String Nome,String Cognome,String CF,Date data) {
			int n;
			n=addCliente(Indirizzo);
			if(n!=0) {
				conn=getConnection();
				String query="insert into privato(cliente_CodiceC,Nome,Cognome,CF,Data_nascita) values("+key+", '"+Nome+"' , '"+Cognome+"', '"+CF+"', '"+data+"' ) ; ";
				n=execUpdate(query);
				releaseConnection(conn);
				return n;
			}
			return 0;
		}
		
		/*Inserire un Operatore.*/
		public int addOperatore(String Nome,String Cognome,Date data,String CF,String Ruolo)
		{
			int n;
			conn=getConnection();
			String query="select max(CodiceO) as maxOperatore from operatore ;";
			execQuery(query);
			try {
				if(rs.next()) {
					key=rs.getInt("maxOperatore");
					key++;
					rs.close();
					pst.close();
					query="insert into operatore (CodiceO,Nome,Cognome,Data_nascita,CF,Ruolo) values( "+key+",'"+Nome+"' ,'"+Cognome+"' , '"+data+"' , '"+CF+"' , '"+Ruolo+"' );";	
					n= execUpdate(query);
					return n;
					}
			}
			catch(SQLException e) {
				releaseConnection(conn);
				System.err.printf(e.getMessage());
			}finally {
				releaseConnection(conn);
			}
			return 0;
		}
		/*Far seguire un cliente un Corso Formativo.*/
		public int addSegueCorsoFormativo(int CodiceC,int CodiceCF) 
		{
			int n;
				String	query="insert into segue (Numero_esami_dati,Cliente_CodiceC,Corso_Formativo_CodiceCF) values( 0 ,"+CodiceC+" ,"+CodiceCF+" );";
				n= execUpdate(query);
				releaseConnection(conn);
				return n;
		}

		public int addAcquistaSoftware(int CodiceS,int CodiceC) 
		{
			int n;
				String	query="insert into acquista(Software_CodiceS,Cliente_CodiceC) values( "+CodiceS+" , "+CodiceC+" ) ;";
				n= execUpdate(query);
				releaseConnection(conn);
				return n;
		}
		
		
		/*Inserire un Software con relativo Sistema Operativo.*/
		public int addSoftwareForSistema(String Nome,String tipo,float Prezzo,String Caratteristica,String Licenza,String Versione,String Sistema,int CodiceP) 
		{
			int n;
			conn=getConnection();
			String query="select max(CodiceS) as MaxCodiceS from software ;";
			execQuery(query);
			try {
				if(rs.next()) {
					key=rs.getInt("MaxCodiceS");
					key++;
					rs.close();
					pst.close();
					query="insert into software(CodiceS,Nome,Tipo,Prezzo,Caratteristica,Licenza,Versione) values ("+key+" ,'"+Nome+"' , '"+tipo+"' , "+Prezzo+" , '"+Caratteristica+"' , '"+Licenza+"' ,'"+Versione+"' ) ;";	
					if(execUpdate(query)!=0) 
					{
						query="insert into lavora_su(Personale_CodiceP,Software_CodiceS) values ( "+CodiceP+" , "+key+" ); ";
						n=execUpdate(query);
						query="insert into sistema_operativo (Sistema,Software_CodiceS) values( '"+Sistema+"' , "+key+" );";
						n= execUpdate(query);
						return n;
					}
				}
			} catch (SQLException e) {
				releaseConnection(conn);
				System.out.println(e.getMessage());
			}finally {
				releaseConnection(conn);
			}
			return 0;
		}
		/*Inserire un Corso Formativo.*/
		public int addCorsoFormativo(String Descrizione,int Ore,Date Data,int numEsami) 
		{
			int n;
			conn=getConnection();
			String query="insert into corso_formativo(Descrizione,Durata_in_ore,Data_inizio,Numero_esami) values( '"+Descrizione+"' , "+Ore+" , '"+Data+"' , "+numEsami+" ) ;";
			n= execUpdate(query);
			releaseConnection(conn);
			return n;
		}
		/*Inserire un Problema segnalato da un determinato Cliente per un Software.*/
		public int addProblema(String Problema,int CodiceC,int CodiceS,int Segnalazioni) 
		{
			int n;
			conn=getConnection();
			String query="insert problema (Descrizione,Numero,Software_CodiceS,Cliente_CodiceC) values ( '"+Problema+"' , "+Segnalazioni+" , "+CodiceS+" , "+CodiceC+" );";
			n=execUpdate(query);
			releaseConnection(conn);
			return n;
		}
		/*Inserire un Attestato per uno specifico Corso Formativo e uno specifico Cliente.*/
		public int addAttestato(Date data,int CodiceCF,int CodiceC)
		{	
			int n;
			conn=getConnection();
			String query="insert into attestato(Data_rilascio,Corso_Formativo_CodiceCF,Cliente_CodiceC) values( '"+data+"' , "+CodiceCF+" , "+CodiceC+" ) ;";
			n= execUpdate(query);
			releaseConnection(conn);
			return n;
		}
		/*Inserire un Cliente che acquista un Software.*/
		public int addAcquista(int CodiceC,int CodiceS)
		{
			int n;
			conn=getConnection();
			String query="insert into acquista(Software_CodiceS,Cliente_CodiceC) values( "+CodiceC+" , "+CodiceS+" );";
			n=execUpdate(query);
			releaseConnection(conn);
			return n;
		}
		/*Inserire un nuovo Telefono/Fax per un Cliente.*/
		public int addTlefono_Fax(char Tipo,String Numero,String Indirizzo) 
		{
			
			int n;
			conn=getConnection();
			String query="select max(CodiceC) as MaxCodiceC from cliente ; ";
			execQuery(query);
			try {
				if(rs.next()) {
					key=rs.getInt("MaxCodiceC");
					key++;
					rs.close();
					pst.close();
					query ="insert into cliente(CodiceC,Indirizzo) values ("+key+" , \""+Indirizzo+"\" ) ;";
					if(execUpdate(query)!=0) 
					{
						query="insert into telefono_fax(Numero,Tipo,Cliente_CodiceC) values( \""+Numero+"\" , \""+Tipo+"\" , "+key+" );";
						n= execUpdate(query);
						releaseConnection(conn);
						return n;
					}
					else 
					{
						query="DELETE FROM Cliente WHERE (CodiceC =  "+key+" );";
						execUpdate(query);
						releaseConnection(conn);
						return 0;
					}
				}
			}catch (SQLException e) 
			{
				releaseConnection(conn);
				System.out.println(e.getMessage());
			}
			return 0;
		}
	}

	public final class Aggiornare
	{
		private PreparedStatement pst;
		private Connection conn;
		public Aggiornare() 
		{
			pst=null;
			conn=null;
		}
		private int execUpdate(String query) 
		{
			try 
			{
				pst=conn.prepareStatement(query);
				int n=pst.executeUpdate();
				pst.close();
				return n;
			} 
			catch (SQLException e) 
			{
				e.printStackTrace();
				return 0;
			}
		}
		/* Aggiungere un addetto al Personale per lavorare su un Software.*/
		public int addLavora_su(int CodiceP,int CodiceS) 
		{
			int n;			
			conn=getConnection();
			String query="insert into lavora_su(Personale_CodiceP,Software_CodiceS) values( "+CodiceP+" , "+CodiceS+" );";
			n=execUpdate(query);
			releaseConnection(conn);
			return n;
		}
		/*Rendere compatibile un Software per un determinato Sistema Operativo. */
		public int SoftwarePerSistema(String Sistema,int CodiceS) 
		{
			int n;
			conn=getConnection();
			String query="insert into sistema_operativo(Sistema,Software_CodiceS) values ( \""+Sistema+"\" , "+CodiceS+" );";
			n=execUpdate(query);
			releaseConnection(conn);
			return n;
		}
		/* Aggiungere un Attestato conseguito da un Cliente.*/
		public int addAttestato(Date data,int CodiceCF,int CodiceC) 
		{
			int n;
			conn=getConnection();
			String query="insert into attestato(Data_rilascio,Corso_Formativo_CodiceCF,Cliente_CodiceC) values ( '"+data+"' , "+CodiceCF+" , "+CodiceC+" );";
			n=execUpdate(query);
			releaseConnection(conn);
			return n;
		}
	}
}

