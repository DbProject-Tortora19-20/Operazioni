package softwarehouse;
import java.sql.Date;
import java.time.LocalDate;
import java.util.Scanner;


public class MainClass {

	public static void main(String[] args){
		SoftwareHouse softwareHouse=new SoftwareHouse();
		int scelta = 0;
		String username,password;
		boolean pass,risolto;
		int CodiceC,CodiceS,CodiceCF,CodiceO,numEsami,durata,segnalazioni,gg,mm,yy;
		String Descrizione,Indirizzo,CF,Nome,Cognome,Tipo,Caratteristica,Versione,Licenza,Sistema,Numero,partita_iva,ragioneSociale,Email;
		char tipo;
		float Prezzo;
		Date data=new Date(System.currentTimeMillis());//restituisce la data del giorno attuale
		Date data_nascita;
		Scanner sc=new Scanner(System.in);
		do {
			System.out.printf("Inserire username:");
			username=sc.nextLine();
			softwareHouse.setUsername(username);
			System.out.printf("Inserire password:");
			password=sc.nextLine();
			softwareHouse.setPassword(password);
			pass=softwareHouse.TestConnection();
			if(!pass)
				System.out.println("Username o password errata");
		}while(!pass);	
		//una volta che le credenziali inserite sono giuste si passa alle varie operazioni/metodi da svolgere
		do{
			System.out.println("1,Inserire un Cliente Privato.");
			System.out.println("2,Inserire un Cliente Aziendale.");
			System.out.println("3,Inserire un Software con relativo Sistema Operativo.");
			System.out.println("4,Inserire un Corso Formativo.");
			System.out.println("5,Inserire un Problema segnalato da un determinato Cliente per un Software.");
			System.out.println("6,Inserire un Attestato per uno specifico Corso Formativo ad uno specifico Cliente.");
			System.out.println("7,Inserire un Operatore.");
			System.out.println("8,Far seguire un cliente un Corso Formativo.");
			System.out.println("9,.Far acquistare un Software a un Cliente");
			System.out.println("10,Rendere compatibile un Software per un determinato Sistema Operativo.");
			System.out.println("11,Inserire un nuovo Telefono/Fax per un Cliente.");
			System.out.println("12,Stampare il numero di esami conseguiti da un Privato.");
			System.out.println("13,Visualizzare il numero di esami mancanti per ogni Cliente inerenti ad un Corso Formativo.");
			System.out.println("14,Mostrare quali Azienda hanno conseguito almeno n esami.");
			System.out.println("15,Visualizzare gli Operatori che hanno preso in carico un determinato Problema.");
			System.out.println("16,Stampare tutti i Sistemi Operativi compatibili per uno specifico Software.");
			System.out.println("17,Mostrare tutti i Clienti che hanno speso un totale di p Euro.");
			System.out.println("18,Visualizzare l'elenco di tutti gli Attestati conseguiti da un Cliente.");
			System.out.println("19,Stampare tutte le Aziende alle quali potrebbe interessare uno specifico Software in base agli acquisti, inserito un tipo di riferimento.");
			System.out.println("20,Visualizzare i Clienti che hanno conseguito un numero di esami pari a quelli previsti dal Corso Formativo");
			System.out.println("21,Aggiornare il numero di esami dati per un Cliente");
			System.out.println("22,Aggiornare il prezzo di un dato Software");
			System.out.println("0,Per Uscire");
			System.out.printf("Inserisci la scelta:");
			scelta=sc.nextInt();
			switch(scelta){
			case 1:{//Inserire un Cliente Privato
				System.out.printf("\n");
				System.out.printf("Inserisci l'Indirizzo:");
				sc.nextLine();
				Indirizzo=sc.nextLine();
				System.out.printf("Inserire un Email:");
				Email=sc.nextLine();
				System.out.printf("Inserisci il nome del Cliente:");
				Nome=sc.nextLine();
				System.out.printf("Inserire il cognome del Cliente:");
				Cognome=sc.nextLine();
				System.out.printf("Inserire il Codice Fiscale del Cliente:");
				CF=sc.nextLine();
				System.out.printf("Inseire il giorno di nascita del Cliente:");
				gg=sc.nextInt();
				System.out.printf("Inseire il mese di nascita del Cliente:");
				mm=sc.nextInt();
				System.out.printf("Inseire l,anno di nascita del Cliente:");
				yy=sc.nextInt();
				LocalDate date=LocalDate.of(yy, mm, gg);
				data_nascita=Date.valueOf(date);
				System.out.printf("Inserisci il numero di Telefono:");
				sc.nextLine();
				Numero=sc.nextLine();
				System.out.printf("Inserisci il Tipo:");
				tipo=sc.next().charAt(0);
				int count=softwareHouse.add.addClientePrivato(Indirizzo,Email,Nome,Cognome,CF,data_nascita,Numero,tipo);
				if(count!=0)
					System.out.println("Operazione Riuscita");
				else
					System.out.println("Operazione non Riuscita");
				System.out.printf("\n");
			}
			break;
			case 2:{//Inserire un Cliente Aziendale
				System.out.printf("\n");
				System.out.printf("Inserisci l'Indirizzo:");
				sc.nextLine();
				Indirizzo=sc.nextLine();
				System.out.printf("Inserire l'Email:");
				Email=sc.nextLine();
				System.out.printf("Inserisci partita iva:");
				partita_iva=sc.nextLine();
				System.out.printf("Inserire Ragione Sociale:");
				ragioneSociale=sc.nextLine();
				System.out.printf("Inserisci il numero di Telefono:");
				Numero=sc.nextLine();
				System.out.printf("Inserisci il Tipo:");
				tipo=sc.next().charAt(0);
				int count=softwareHouse.add.addClienteAziende(Indirizzo,Email,partita_iva,ragioneSociale,Numero,tipo);
				if(count!=0)
					System.out.println("Operazione Riuscita");
				else
					System.out.println("Operazione non Riuscita");
				System.out.printf("\n");			
			}
			break;
			case 3://Inserire un Software con relativo Sistema Operativo
			{
				System.out.printf("\n");
				System.out.printf("Inserire il nome del Software:");
				sc.nextLine();
				Nome=sc.nextLine();
				System.out.printf("Inserire il tipo di Software:");
				Tipo=sc.nextLine();
				System.out.printf("Inserire la versione del Software:");
				Versione=sc.nextLine();
				System.out.printf("Inserire il prezzo del Software:");
				Prezzo=sc.nextFloat();
				System.out.printf("Inserire le caratteristiche del Software:");
				sc.nextLine();
				Caratteristica=sc.nextLine();
				System.out.printf("Inserire il Sistema Operativo associato al Software:");
				Sistema=sc.nextLine();
				System.out.printf("Inserire la licenza del Software:");
				Licenza=sc.nextLine();
				System.out.printf("Inserire il Codice del Operatore:");
				CodiceO=sc.nextInt();
				int risultato=softwareHouse.add.addSoftwareForSistema(Nome, Tipo, Prezzo, Caratteristica, Licenza, Versione, Sistema,CodiceO);
				if(risultato!=0)
					System.out.println("Operazione Riuscita");
				else
					System.out.println("Operazione non Riuscita");
				System.out.printf("\n");
			}
			break;
			case 4:{//Inserire un Corso Formativo
				System.out.printf("\n");
				System.out.printf("Inserire una descrizione del Corso Formativo:");
				sc.nextLine();
				Descrizione=sc.nextLine();
				System.out.printf("Inserire la durata del Corso Formativo:");
				durata=sc.nextInt();
				System.out.printf("Inserire il numero di esami previsti dal Corso Formativo:");
				numEsami=sc.nextInt();
				int count=softwareHouse.add.addCorsoFormativo(Descrizione,durata, data, numEsami);
				if(count!=0)
					System.out.println("Operazione Riuscita");
				else
					System.out.println("Operazione Fallita");
				System.out.printf("\n");
			}
			break;
				
			case 5:{//Inserire un Problema segnalato da un determinato Cliente per un Software
				System.out.printf("\n");
				System.out.printf("Inserisci una descrizione del Problema:");
				sc.nextLine();
				Descrizione=sc.nextLine();
				System.out.printf("Inserisci il numero di segnalazioni del Problema:");
				segnalazioni=sc.nextInt();
				System.out.printf("Inserisci il Codice Cliente:");
				CodiceC=sc.nextInt();
				System.out.printf("Inserisci il Codice del Software:");
				CodiceS=sc.nextInt();
				System.out.printf("Inserisci il Codice dell'Operatore:");
				CodiceO=sc.nextInt();
				risolto=false;
				int count=softwareHouse.add.addProblema(Descrizione,CodiceO,CodiceC,CodiceS,segnalazioni,risolto);
				if(count!=0) 
					System.out.println("Operazione Riuscita");
				else
					System.out.println("Operazione Fallita");
				System.out.printf("\n");
			}
			break;
			case 6:{//Inserire un Attestato per uno specifico Corso Formativo ad uno specifico Cliente
				System.out.printf("\n");
				System.out.printf("Inserire il Codice del Corso Formativo:");
				CodiceCF=sc.nextInt();
				System.out.printf("Inserisco il Codice del Cliente:");
				CodiceC=sc.nextInt();
				int risultato=softwareHouse.add.addAttestato(data, CodiceCF, CodiceC);
				if(risultato!=0)
					System.out.println("Operazione Riuscita");
				else
					System.out.println("Operazione Fallita");
				System.out.printf("\n");
			}
			break;
			case 7:{//Inserire un Operatore.
				System.out.printf("\n");
				sc.nextLine();
				System.out.printf("Inserire il nome del Operatore:");
				Nome=sc.nextLine();
				System.out.printf("Inserisco il cognome del Operatore:");
				Cognome=sc.nextLine();
				System.out.printf("Inserisco il codice fiscale del Operatore:");
				CF=sc.nextLine();
				System.out.printf("Inseire il giorno di nascita del Cliente:");
				gg=sc.nextInt();
				System.out.printf("Inseire il mese di nascita del Cliente:");
				mm=sc.nextInt();
				System.out.printf("Inseire l'anno di nascita del Cliente:");
				yy=sc.nextInt();
				LocalDate date=LocalDate.of(yy, mm, gg);
				data_nascita=Date.valueOf(date);
				int risultato=softwareHouse.add.addOperatore(Nome, Cognome, data_nascita, CF);
				if(risultato!=0) 
					System.out.println("Operazione Riuscita");
				else
					System.out.println("Operazione Fallita");
				System.out.printf("\n");
			}
			break;
			case 8:{//Far seguire un cliente un Corso Formativo.
				System.out.printf("\n");
				System.out.printf("Inserisci il Codice del Corso Formativo:");
				CodiceCF=sc.nextInt();
				System.out.printf("Inserire il Codice del Cliente:");
				CodiceC=sc.nextInt();
				int n=softwareHouse.add.addSegueCorsoFormativo(CodiceC,CodiceCF);
				if(n!=0)
					System.out.println("Operazione Riuscita");
				else
					System.out.println("Operazione Fallita");
				System.out.printf("\n");
			}
			break;
			case 9:{//.Far acquistare un Software a un Cliente.
				System.out.printf("\n");
				System.out.printf("Inserisci il Codice del Software:");
				CodiceS=sc.nextInt();
				System.out.printf("Inserire il Codice del Cliente:");
				CodiceC=sc.nextInt();
				int n=softwareHouse.add.addAcquista(CodiceS,CodiceC);
				if(n!=0)
					System.out.println("Operazione Riuscita");
				else
					System.out.println("Operazione Fallita");
				System.out.printf("\n");
			}
			break;
			case 10:{//Rendere compatibile un Software per un determinato Sistema Operativo
				System.out.printf("\n");
				System.out.printf("Inserire il Sistema compatibile per un Software:");
				Sistema=sc.nextLine();
				System.out.printf("Inserire il Codice del Software compatibile con il Sistema Operativo:");
				CodiceS=sc.nextInt();
				int risultato=softwareHouse.add.SoftwarePerSistema(Sistema, CodiceS);
				if(risultato!=0)
					System.out.println("Operazione Riuscita");
				else
					System.out.println("Operazione Fallita");
				System.out.printf("\n");
			}
			break;
	
			case 11:{//Inserire un nuovo Telefono/Fax per un Cliente
				System.out.printf("\n");
				System.out.printf("inserire il Codice del Cliente: ");
				CodiceC=sc.nextInt();
				System.out.printf("Inserire il tipo 'F'se � Fax,'T' se � Telefono oppure 'E' se � entrambi: ");
				sc.nextLine();
				tipo=sc.next().charAt(0);
				System.out.printf("Inserire il numero del Telefono/Fax: ");
				Numero=sc.next();
				int risultato=softwareHouse.add.addTlefono_Fax(CodiceC,tipo, Numero);
				if(risultato!=0)
					System.out.println("Operazione Riuscita");
				else
					System.out.println("Operazione Fallita");
				System.out.printf("\n");
				
			}
			break;
			case 12:{//Stampare il numero di esami conseguiti da un Privato
				System.out.printf("\n");
				System.out.println("Inserisco il codice di un Cliente Privato:");
				softwareHouse.show.numEsamiPrivato(sc.nextInt());
				System.out.printf("\n");
			}
			break;
			case 13:{//Visualizzare il numero di esami mancanti per ogni Cliente inerenti ad un Corso Formativo
				System.out.printf("\n");
				System.out.println("Inserisco il codice del Cliente:");
				softwareHouse.show.esamiMancanti(sc.nextInt());
				System.out.printf("\n");
			}
			break;
			case 14:{//Mostrare quali Azienda hanno conseguito almeno n esami
				System.out.printf("\n");
				System.out.println("Inserisci il numero di esami che un Cliente Azienda ha almeno superato:");
				numEsami=sc.nextInt();
				System.out.println("Inserire il Codice del Cliente:");
				CodiceC=sc.nextInt();
				softwareHouse.show.esami(numEsami,CodiceC);
				System.out.printf("\n");
			}
			break;
			case 15:{//Visualizzare gli Operatori che hanno preso in carico un determinato Problema.
				System.out.printf("\n");
				System.out.printf("Inserire il codice del Software:");
				CodiceS=sc.nextInt();
				sc.nextLine();
				System.out.printf("Inserire il numero di segnalazioni del Problema:");
				segnalazioni=sc.nextInt();
				softwareHouse.show.OperatoriInCarico(segnalazioni, CodiceS);
				System.out.printf("\n");
			}
			break;
			case 16:{//Stampare tutti i Sistemi Operativi compatibili per uno specifico Software
				System.out.printf("\n");
				System.out.println("Inserisci il codice del Software:");
				softwareHouse.show.sitemiCompatibiliS(sc.nextInt());
				System.out.printf("\n");
			}
			break;
			case 17:{//Mostrare tutti i Clienti che hanno speso un totale di p Euro
				System.out.printf("\n");
				System.out.println("Inserire un Prezzo:");
				softwareHouse.show.acquistoSoftware(sc.nextFloat());
				System.out.printf("\n");
			}
			break;
			case 18:{//Visualizzare l'elenco di tutti gli Attestati conseguiti da un Cliente
				System.out.printf("\n");
				System.out.println("inserire il codice del Cliente:");
				softwareHouse.show.elencoAttestati(sc.nextInt());
				System.out.printf("\n");
			}
			break;
			case 19:{//Stampare tutte le Aziende alle quali potrebbe interessare uno specifico Software in base agli acquisti, inserito un tipo di riferimento
				System.out.printf("\n");
				System.out.println("inserisci il tipo di Software cui si vuol fare riferimento:");
				softwareHouse.show.aziendeInteressate(sc.nextLine());
				System.out.printf("\n");
			}
			break;

			case 20:{//Visualizzare i Clienti che hanno conseguito un numero di esami pari a quelli previsti dal Corso Formativo
			System.out.printf("\n");
			System.out.println("Visualizzo i clienti che hanno conseguito pari numero di esami a quelli previsti dal Corso Formativo:");
			softwareHouse.show.ClientiEsami();
			System.out.printf("\n");
			}
			break;
			case 21:{//Aggiornare il numero di esami dati per un Cliente
				int risultato;
				System.out.printf("\n");
				System.out.printf("Inserire un Codice Cliente:");
				CodiceC=sc.nextInt();
				System.out.printf("Inserire il Codice del Corso Formativo:");
				CodiceCF=sc.nextInt();
				risultato=softwareHouse.update.updateEsami(CodiceC,CodiceCF);
				if(risultato!=0)
					System.out.println("Operazione Riuscita");
				else
					System.out.println("Operazione Fallita");
				System.out.printf("\n");
				
			}
			break;
			case 22:{
				int n;
				System.out.printf("\n");
				System.out.printf("Inserire un Codice Software:");
				CodiceS=sc.nextInt();
				System.out.printf("Inserire un Prezzo:");
				Prezzo=sc.nextFloat();
				n=softwareHouse.update.updatePrezzo(CodiceS, Prezzo);
				if(n!=0)
					System.out.println("Operazione Riuscita");
				else
					System.out.println("Operazione Fallita");
				System.out.printf("\n");
			}
			break;
			case 23:{
				System.out.printf("\n");
				System.out.printf("Inserire il Codice:");
				CodiceS=sc.nextInt();
				System.out.printf("Inserire il Numero di segnalazioni:");
				segnalazioni=sc.nextInt();
				System.out.printf("Inserire se il Problema � stato risolto o meno:");
				risolto=sc.nextBoolean();
				int risultato = softwareHouse.update.updateRisolto(CodiceS, segnalazioni, risolto);
				if(risultato!=0)	
					System.out.println("Operazione Riuscita");
				else
					System.out.println("Operazione Fallita");
				System.out.printf("\n");
			}
			break;
			case 0:{
				System.out.println("Uscita");
				break;
			}
			default:{
				System.out.println("La scelta non � tra quelle disponibili,Riprovare");
				break;
			}

			}
		}while(scelta!=0);
		sc.close();
	}
}
