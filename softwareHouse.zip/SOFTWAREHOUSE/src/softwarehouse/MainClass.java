package softwarehouse;
import java.sql.Date;
import java.time.LocalDate;
import java.util.Scanner;


public class MainClass {

	public static void main(String[] args){
		SoftwareHouse softwareHouse=new SoftwareHouse();
		int scelta=0;
		String username,password;
		boolean pass,risolto;
		int CodiceC,CodiceS,CodiceCF,CodiceO,numEsami,durata,segnalazioni,gg,mm,yy;
		String Descrizione,Indirizzo,CF,Nome,Cognome,Tipo,Caratteristica,Versione,Licenza,Sistema,Numero,partita_iva,ragioneSociale,Email;
		char tipo;
		float Prezzo;
		Date data=new Date(System.currentTimeMillis());//restituisce la data del giorno attuale
		Date data_nascita;
		Scanner sc=new Scanner(System.in);
		do 
		{
			System.out.printf("Inserire username: ");
			username=sc.nextLine();
			softwareHouse.setUsername(username);
			System.out.printf("Inserire password: ");
			password=sc.nextLine();
			softwareHouse.setPassword(password);
			pass=softwareHouse.TestConnection();
			if(!pass)
				System.err.println("Username o password errata!");
		}while(!pass);	
		//una volta che le credenziali inserite sono giuste si passa alle varie operazioni/metodi da svolgere
		do
		{
			System.out.println("\n******************************************************************************************************************************************");
			System.out.println("1)  Inserisci un Cliente Privato;");
			System.out.println("2)  Inserisci un Cliente Aziendale;");
			System.out.println("3)  Inserisci un Software con relativo Sistema Operativo;");
			System.out.println("4)  Inserisci un Corso Formativo;");
			System.out.println("5)  Inserisci un Problema segnalato da un determinato Cliente per un Software;");
			System.out.println("6)  Inserisci un Attestato per uno specifico Corso Formativo ad uno specifico Cliente;");
			System.out.println("7)  Inserisci un Operatore;");
			System.out.println("8)  Fai seguire un Corso Formativo ad un Cliente;");
			System.out.println("9)  Fai acquistare un Software ad un Cliente;");
			System.out.println("10) Rendi compatibile un Software per un determinato Sistema Operativo;");
			System.out.println("11) Inserisci un nuovo Telefono/Fax per un Cliente;");
			System.out.println("12) Stampa il numero di esami conseguiti da un Privato;");
			System.out.println("13) Visualizza il numero di esami mancanti per ogni Cliente inerenti ad un Corso Formativo;");
			System.out.println("14) Mostra quali Azienda hanno conseguito almeno n esami;");
			System.out.println("15) Visualizza gli Operatori che hanno preso in carico un determinato Problema;");
			System.out.println("16) Stampa tutti i Sistemi Operativi compatibili per uno specifico Software;");
			System.out.println("17) Mostra tutti i Clienti che hanno speso un totale di p Euro;");
			System.out.println("18) Visualizza l'elenco di tutti gli Attestati conseguiti da un Cliente;");
			System.out.println("19) Stampa tutte le Aziende alle quali potrebbe interessare uno specifico Software in base agli acquisti, inserito un tipo di riferimento;");
			System.out.println("20) Visualizza i Clienti che hanno conseguito un numero di esami pari a quelli previsti dal Corso Formativo;");
			System.out.println("21) Visualizzare quale Software ha avuto piu Problemi;");
			System.out.println("22) Visualizzare l'operatore che si prende carico di un Problema di un determinato Software;");
			System.out.println("23) Visualizzare i numeri di Telefono/Fax di un Cliente;");
			System.out.println("24) Quanti Clienti hanno acquistato un Software;");
			System.out.println("25) Aggiorna il numero di esami dati per un Cliente;");
			System.out.println("26) Aggiorna il prezzo di un dato Software;");
			System.out.println("27) Aggiorna il campo risolto in Problema;");
			System.out.println("0)  Esci dal menu.");
			System.out.println("******************************************************************************************************************************************");
			System.out.println("\nInserisci la scelta:");
			scelta=sc.nextInt();
			switch(scelta)
			{
				case 1:
				{
					//Inserire un Cliente di tipo Privato
					System.out.println("\nInserisci l'Indirizzo: ");
					sc.nextLine();
					Indirizzo=sc.nextLine();
					System.out.println("\nInserisci l'Email del Cliente: ");
					Email=sc.nextLine();
					System.out.println("\nInserisci il nome del Cliente: ");
					Nome=sc.nextLine();
					System.out.println("\nInserisci il cognome del Cliente: ");
					Cognome=sc.nextLine();
					System.out.println("\nInserisci il Codice Fiscale del Cliente: ");
					CF=sc.nextLine();
					System.out.println("\nInserisci il giorno di nascita del Cliente: ");
					gg=sc.nextInt();
					System.out.println("\nInserisci il mese di nascita del Cliente: ");
					mm=sc.nextInt();
					System.out.println("\nInserisci l'anno di nascita del Cliente: ");
					yy=sc.nextInt();
					LocalDate date=LocalDate.of(yy, mm, gg);
					data_nascita=Date.valueOf(date);
					System.out.println("\nInserisci il numero di Telefono: ");
					sc.nextLine();
					Numero=sc.nextLine();
					System.out.println("\nInserisci il Tipo[T(telefono),F(fax),E(entrambi)]: ");
					tipo=sc.next().charAt(0);
					int count=softwareHouse.add.addClientePrivato(Indirizzo,Email,Nome,Cognome,CF,data_nascita,Numero,tipo);
					if(count!=0)
						System.out.println("OPERAZIONE RIUSCITA");
					else
						System.err.println("OPERAZIONE NON RIUSCITA");
				}
				break;
				case 2:
				{
					//Inserire un Cliente di tipo Azienda
					System.out.println("\nInserisci l'Indirizzo: ");
					sc.nextLine();
					Indirizzo=sc.nextLine();
					System.out.println("\nInserisci l'Email: ");
					Email=sc.nextLine();
					System.out.println("\nInserisci la Partita Iva: ");
					partita_iva=sc.nextLine();
					System.out.println("\nInserisci la Ragione Sociale: ");
					ragioneSociale=sc.nextLine();
					System.out.println("\nInserisci il numero di Telefono: ");
					Numero=sc.nextLine();
					System.out.println("\nInserisci il Tipo[T(telefono),F(fax),E(entrambi)]: ");
					tipo=sc.next().charAt(0);
					int count=softwareHouse.add.addClienteAziende(Indirizzo,Email,partita_iva,ragioneSociale,Numero,tipo);
					if(count!=0)
						System.out.println("OPERAZIONE RIUSCITA");
					else
						System.err.println("OPERAZIONE NON RIUSCITA");		
				}
				break;
				case 3:
				{
					//Inserire un Software con relativo Sistema Operativo
					System.out.println("\nInserisci il Nome del Software: ");
					sc.nextLine();
					Nome=sc.nextLine();
					System.out.println("\nInserisci il Tipo di Software: ");
					Tipo=sc.nextLine();
					System.out.println("\nInserisci la Versione del Software: ");
					Versione=sc.nextLine();
					System.out.println("\nInserisci il Prezzo del Software: ");
					Prezzo=sc.nextFloat();
					System.out.println("\nInserisci le Caratteristiche del Software: ");
					sc.nextLine();
					Caratteristica=sc.nextLine();
					System.out.println("\nInserisci il Sistema Operativo associato al Software: ");
					Sistema=sc.nextLine();
					System.out.println("\nInserisci la Licenza del Software: ");
					Licenza=sc.nextLine();
					int risultato=softwareHouse.add.addSoftwareForSistema(Nome, Tipo, Prezzo, Caratteristica, Licenza, Versione, Sistema);
					if(risultato!=0)
						System.out.println("OPERAZIONE RIUSCITA");
					else
						System.err.println("OPERAZIONE NON RIUSCITA");	
				}
				break;
				case 4:
				{
					//Inserire un Corso Formativo
					System.out.println("\nInserisci una Descrizione del Corso Formativo: ");
					sc.nextLine();
					Descrizione=sc.nextLine();
					System.out.println("\nInserisci la Durata in ore del Corso Formativo: ");
					durata=sc.nextInt();
					System.out.println("\nInserisci il numero di esami previsti dal Corso Formativo: ");
					numEsami=sc.nextInt();
					int count=softwareHouse.add.addCorsoFormativo(Descrizione,durata, data, numEsami);
					if(count!=0)
						System.out.println("OPERAZIONE RIUSCITA");
					else
						System.err.println("OPERAZIONE NON RIUSCITA");
				}
				break;
				case 5:
				{
					//Inserire un Problema segnalato da un determinato Cliente per un Software
					System.out.println("\nInserisci una Descrizione del Problema: ");
					sc.nextLine();
					Descrizione=sc.nextLine();
					System.out.println("\nInserisci il Codice Cliente: ");
					CodiceC=sc.nextInt();
					System.out.println("\nInserisci il Codice del Software: ");
					CodiceS=sc.nextInt();
					System.out.println("\nInserisci il Codice dell'Operatore: ");
					CodiceO=sc.nextInt();
					risolto=false;
					int count=softwareHouse.add.addProblema(Descrizione,CodiceO,CodiceC,CodiceS,risolto);
					if(count!=0)
						System.out.println("OPERAZIONE RIUSCITA");
					else
						System.err.println("OPERAZIONE NON RIUSCITA");
				}
				break;
				case 6:
				{
					//Inserire un Attestato per uno specifico Corso Formativo ad uno specifico Cliente
					System.out.println("\nInserisci il Codice del Corso Formativo: ");
					CodiceCF=sc.nextInt();
					System.out.println("\nInserisci il Codice del Cliente: ");
					CodiceC=sc.nextInt();
					int risultato=softwareHouse.add.addAttestato(data, CodiceCF, CodiceC);
					if(risultato!=0)
						System.out.println("OPERAZIONE RIUSCITA");
					else
						System.err.println("OPERAZIONE NON RIUSCITA");
				}
				break;
				case 7:
				{
					//Inserire un Operatore
					System.out.println("\nInserisci il Nome del Operatore: ");
					Nome=sc.nextLine();
					System.out.println("\nInserisci il Cognome del Operatore: ");
					Cognome=sc.nextLine();
					System.out.println("\nInserisci il Codice Fiscale del Operatore: ");
					CF=sc.nextLine();
					System.out.println("\nInserisci il giorno di nascita del Cliente: ");
					gg=sc.nextInt();
					System.out.println("\nInserisci il mese di nascita del Cliente: ");
					mm=sc.nextInt();
					System.out.println("\nInserisci l'anno di nascita del Cliente: ");
					yy=sc.nextInt();
					LocalDate date=LocalDate.of(yy, mm, gg);
					data_nascita=Date.valueOf(date);
					int risultato=softwareHouse.add.addOperatore(Nome, Cognome, data_nascita, CF);
					if(risultato!=0) 
						System.out.println("OPERAZIONE RIUSCITA");
					else
						System.err.println("OPERAZIONE NON RIUSCITA");
				}
				break;
				case 8:
				{
					//Far seguire un cliente un Corso Formativo
					System.out.println("\nInserisci il Codice del Corso Formativo: ");
					CodiceCF=sc.nextInt();
					System.out.println("\nInserisci il Codice del Cliente: ");
					CodiceC=sc.nextInt();
					int n=softwareHouse.add.addSegueCorsoFormativo(CodiceC,CodiceCF);
					if(n!=0)
						System.out.println("OPERAZIONE RIUSCITA");
					else
						System.err.println("OPERAZIONE NON RIUSCITA");
				}
				break;
				case 9:
				{
					//Far acquistare un Software a un Cliente
					System.out.println("\nInserisci il Codice del Software: ");
					CodiceS=sc.nextInt();
					System.out.println("\nInserisci il Codice del Cliente: ");
					CodiceC=sc.nextInt();
					int n=softwareHouse.add.addAcquista(CodiceS,CodiceC);
					if(n!=0)
						System.out.println("OPERAZIONE RIUSCITA");
					else
						System.err.println("OPERAZIONE NON RIUSCITA");
				}
				break;
				case 10:
				{
					//Rendere compatibile un Software per un determinato Sistema Operativo
					System.out.println("\nInserisci il Sistema compatibile per un Software: ");
					Sistema=sc.nextLine();
					System.out.println("\nInserisci il Codice del Software compatibile con il Sistema Operativo: ");
					CodiceS=sc.nextInt();
					int risultato=softwareHouse.add.SoftwarePerSistema(Sistema, CodiceS);
					if(risultato!=0)
						System.out.println("OPERAZIONE RIUSCITA");
					else
						System.err.println("OPERAZIONE NON RIUSCITA");
				}
				break;
				case 11:
				{
					//Inserire un nuovo Telefono/Fax per un Cliente
					System.out.println("\nInserire il Codice del Cliente: ");
					CodiceC=sc.nextInt();
					System.out.println("\nInserisci il : Tipo[T(telefono),F(fax),E(entrambi)]: ");
					sc.nextLine();
					tipo=sc.next().charAt(0);
					System.out.println("\nInserisci il Numero del Telefono/Fax: ");
					Numero=sc.next();
					int risultato=softwareHouse.add.addTlefono_Fax(CodiceC,tipo, Numero);
					if(risultato!=0)
						System.out.println("OPERAZIONE RIUSCITA");
					else
						System.err.println("OPERAZIONE NON RIUSCITA");
				}
				break;
				case 12:
				{
					//Stampare il numero di esami conseguiti da un Privato
					System.out.println("\nInserisci il Codice di un Cliente Privato: ");
					softwareHouse.show.numEsamiPrivato(sc.nextInt());
					System.out.println("\n");
				}
				break;
				case 13:
				{
					//Visualizzare il numero di esami mancanti per ogni Cliente inerenti ad un Corso Formativo
					System.out.println("\nInserisci il Codice del Cliente: ");
					softwareHouse.show.esamiMancanti(sc.nextInt());
					System.out.println("\n");
				}
				break;
				case 14:
				{
					//Mostrare quali Azienda hanno conseguito almeno n esami
					System.out.println("\nInserisci il Numero di esami che un Cliente Azienda ha almeno superato: ");
					numEsami=sc.nextInt();
					System.out.println("\nInserisci il Codice del Cliente: ");
					CodiceC=sc.nextInt();
					softwareHouse.show.esami(numEsami,CodiceC);
					System.out.println("\n");
				}
				break;
				case 15:
				{
					//Visualizzare gli Operatori che hanno preso in carico un determinato Problema
					System.out.println("\nInserisci il Codice del Software: ");
					CodiceS=sc.nextInt();
					sc.nextLine();
					System.out.println("\nInserisci il Numero di segnalazioni del Problema: ");
					segnalazioni=sc.nextInt();
					softwareHouse.show.OperatoriInCarico(segnalazioni, CodiceS);
					System.out.println("\n");
				}
				break;
				case 16:
				{
					//Stampare tutti i Sistemi Operativi compatibili per uno specifico Software
					System.out.println("\nInserisci il Codice del Software: ");
					softwareHouse.show.sitemiCompatibiliS(sc.nextInt());
					System.out.println("\n");
				}
				break;
				case 17:
				{
					//Mostrare tutti i Clienti che hanno speso un totale di p Euro
					System.out.println("\nInserisci un Prezzo: ");
					softwareHouse.show.acquistoSoftware(sc.nextFloat());
					System.out.println("\n");
				}
				break;
				case 18:
				{
					//Visualizzare l'elenco di tutti gli Attestati conseguiti da un Cliente
					System.out.println("\nInserisci il Codice del Cliente: ");
					softwareHouse.show.elencoAttestati(sc.nextInt());
					System.out.println("\n");
				}
				break;
				case 19:
				{
					//Stampare tutte le Aziende alle quali potrebbe interessare uno specifico Software in base agli acquisti, inserito un tipo di riferimento
					System.out.println("\nInserisci il Tipo di Software cui si vuol fare riferimento: ");
					softwareHouse.show.aziendeInteressate(sc.nextLine());
					System.out.println("\n");
				}
				break;
				case 20:
				{
					//Visualizzare i Clienti che hanno conseguito un numero di esami pari a quelli previsti dal Corso Formativo
					System.out.println("\nVisualizzazione dei clienti che hanno conseguito un numero di esami pari a quelli previsti dal Corso Formativo: ");
					softwareHouse.show.ClientiEsami();
					System.out.println("\n");
				}
				break;
				case 21:
				{
					//Visualizzare quale Software ha avuto piu Problemi
					System.out.println("\nVisualizzazione dei Software che hanno avuto il maggior numero di Problemi:");
					softwareHouse.show.SoftwareProblemi();
					System.out.println("\n");
				}
				break;
				case 22:
				{
					//Visualizzare l'operatore che si prende carico di un Problema di un determinato Software
					System.out.println("\nInserisci il Codice del Software:");
					CodiceS=sc.nextInt();
					sc.nextLine();
					System.out.println("\nInserisci il Numero di segnalazioni del Problema:");
					segnalazioni=sc.nextInt();
					softwareHouse.show.OperatorePerProblema(CodiceS, segnalazioni);
					System.out.println("\n");
				}
				break;
				case 23:
				{
					//Visualizzare i numeri di Telefono/Fax di un Cliente
					System.out.println("\nInserisci il Codice del Cliente:");
					softwareHouse.show.TelefonoFaxCliente(sc.nextInt());
					System.out.println("\n");
				}
				break;
				case 24:
				{
					//Quanti Clienti hanno acquistato un Software
					System.out.println("\nInserisci il Codice del Software:");
					softwareHouse.show.NumClientiSoftware(sc.nextInt());
					System.out.println("\n");
				}
				break;
				case 25:
				{
					//Aggiornare il numero di esami dati per un Cliente
					int risultato;
					System.out.println("\nInserisci il Codice del Cliente: ");
					CodiceC=sc.nextInt();
					System.out.println("\nInserisci il Codice del Corso Formativo: ");
					CodiceCF=sc.nextInt();
					risultato=softwareHouse.update.updateEsami(CodiceC,CodiceCF);
					if(risultato!=0)
						System.out.println("OPERAZIONE RIUSCITA");
					else
						System.err.println("OPERAZIONE NON RIUSCITA");
				}
				break;
				case 26:
				{
					//Aggiornare il prezzo di un dato Software
					System.out.println("\nInserisci il Codice del Software: ");
					CodiceS=sc.nextInt();
					System.out.println("\nInserisci il Prezzo del Software: ");
					Prezzo=sc.nextFloat();
					int n=softwareHouse.update.updatePrezzo(CodiceS, Prezzo);
					if(n!=0)
						System.out.println("OPERAZIONE RIUSCITA");
					else
						System.err.println("OPERAZIONE NON RIUSCITA");
				}
				break;
				case 27:
				{
					//Aggiornare Risolto in Problema
					System.out.printf("\nInserire il Codice del Problema: ");
					CodiceS=sc.nextInt();
					System.out.println("\nInserisci il Numero di segnalazioni: ");
					segnalazioni=sc.nextInt();
					System.out.println("\nInserisci false(Problema non risolto), true(Problema risolto): ");
					risolto=sc.nextBoolean();
					int risultato=softwareHouse.update.updateRisolto(CodiceS, segnalazioni, risolto);
					if(risultato!=0)	
						System.out.println("OPERAZIONE RIUSCITA");
					else
						System.err.println("OPERAZIONE NON RIUSCITA");
				}
				break;
				case 0:
				{
					//Uscita dal menu
					System.out.println("\nSei appena uscito dal menu.");
					break;
				}
				default:
				{
					//Gestione dei casi non previsti dal menu di scelta 
					System.err.println("\nLa scelta non � tra quelle disponibili, RIPROVA.");
					break;
				}
			}
		}while(scelta!=0);
		sc.close();
	}
}